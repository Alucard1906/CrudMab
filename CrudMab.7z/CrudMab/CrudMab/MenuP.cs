﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CrudMab
{
    public partial class MenuP : Form
    {
        public MenuP()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" ");
        }

        private void toolStripMenuItem7_Click(object sender, EventArgs e)
        {
            process1.StartInfo.FileName = @"C:\Program Files\Google\Chrome\Application\chrome.exe";
            process1.Start();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {
            process1.StartInfo.FileName = @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge";
            process1.Start();
        }

        private void toolStripMenuItem9_Click(object sender, EventArgs e)
        {
            process1.StartInfo.FileName = @"C:\Program Files\Mozilla Firefox\firefox";
            process1.Start();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            process1.StartInfo.FileName = @"C:\Program Files (x86)\Microsoft Office\root\Office16\WINWORD";
            process1.Start();
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {
            process1.StartInfo.FileName = @"C:\Program Files (x86)\Microsoft Office\root\Office16\EXCEL";
            process1.Start();
        }
    }
}

