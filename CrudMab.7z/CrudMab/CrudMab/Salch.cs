﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CrudMab
{
    public partial class Salch : Form
    {
        public Salch()
        {
            InitializeComponent();
        }

        int i = 0;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tm_Tick(object sender, EventArgs e)
        {
            //MessageBox.Show("Olá");


            //  lbl.Text = i++.ToString();
            // if (i == 10)
            //{
            //fazer parar
            //    tm.Stop();
            //}
            try
            {
                lbl.Text = prb.Value++.ToString() + "%";

                if (prb.Value == 100) {
                    //DIRECIONAR PARA TELA DE LOGIN
                    lbl.Text = "100%";
                tm.Stop();
                this.Hide();
                    Login frmLogin = new Login();
                    frmLogin.Show();
                }
            }
            catch (Exception erro) {
                MessageBox.Show("Tratar o erro");
            }
        }

        private void lbl_Click(object sender, EventArgs e)
        {
           
        }
    }
}
